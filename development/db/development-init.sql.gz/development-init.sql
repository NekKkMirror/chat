--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0 (Debian 17.0-1.pgdg120+1)
-- Dumped by pg_dump version 17.0 (Ubuntu 17.0-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.users_chats DROP CONSTRAINT IF EXISTS "FK_a91c85f9e29b30da5629b555216";
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS "FK_819e6bb0ee78baf73c398dc707f";
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS "FK_36bc604c820bb9adc4c75cd4115";
ALTER TABLE IF EXISTS ONLY public.users_chats DROP CONSTRAINT IF EXISTS "FK_1ddad94a473a2a60bee5dc6d9d0";
DROP INDEX IF EXISTS public."IDX_a91c85f9e29b30da5629b55521";
DROP INDEX IF EXISTS public."IDX_1ddad94a473a2a60bee5dc6d9d";
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS "UQ_fe0bb3f6520ee0469504521e710";
ALTER TABLE IF EXISTS ONLY public.chats DROP CONSTRAINT IF EXISTS "UQ_f63b5cc5bf67e5251f28301d7e0";
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS "PK_a3ffb1c0c8416b9fc6f907b7433";
ALTER TABLE IF EXISTS ONLY public.users_chats DROP CONSTRAINT IF EXISTS "PK_649ecf9d0f35aa1985f9b247218";
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS "PK_18325f38ae6de43878487eff986";
ALTER TABLE IF EXISTS ONLY public.chats DROP CONSTRAINT IF EXISTS "PK_0117647b3c4a4e5ff198aeb6206";
DROP TABLE IF EXISTS public.users_chats;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.messages;
DROP TABLE IF EXISTS public.chats;
DROP EXTENSION IF EXISTS "uuid-ossp";
--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chats; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public.chats (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chats OWNER TO dev;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public.messages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    text character varying NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "chatId" uuid,
    "authorId" uuid
);


ALTER TABLE public.messages OWNER TO dev;

--
-- Name: users; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    username character varying NOT NULL
);


ALTER TABLE public.users OWNER TO dev;

--
-- Name: users_chats; Type: TABLE; Schema: public; Owner: dev
--

CREATE TABLE public.users_chats (
    "usersId" uuid NOT NULL,
    "chatsId" uuid NOT NULL
);


ALTER TABLE public.users_chats OWNER TO dev;

--
-- Data for Name: chats; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public.chats (id, name, "createdAt") FROM stdin;
4ca4d800-edb9-487c-b2a7-dd18343043ef	blog	2024-11-02 19:47:28.390216
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public.messages (id, text, "createdAt", "chatId", "authorId") FROM stdin;
9a81570e-ccae-448e-943b-c0abefd5588f	hey	2024-11-02 19:51:31.108577	4ca4d800-edb9-487c-b2a7-dd18343043ef	2f889abb-b721-41a0-a13b-674d79f6fc64
1a607e4f-f3bd-4951-8a38-d3fdf4eabfec	heyyyy how you	2024-11-02 19:51:43.996844	4ca4d800-edb9-487c-b2a7-dd18343043ef	b2536577-6df2-42af-8326-6ece6f73202a
80ead1f6-86ac-414d-9846-7081438980f1	i'm good how you?	2024-11-02 19:52:55.299731	4ca4d800-edb9-487c-b2a7-dd18343043ef	2f889abb-b721-41a0-a13b-674d79f6fc64
c8587dc5-24df-4481-bddb-ed465f0cb18e	hi	2024-11-02 19:53:10.342735	4ca4d800-edb9-487c-b2a7-dd18343043ef	e28ddbc3-6036-49c8-ba11-66fb97dc8ca6
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public.users (id, "createdAt", username) FROM stdin;
2f889abb-b721-41a0-a13b-674d79f6fc64	2024-11-02 19:46:11.116707	un-1
b2536577-6df2-42af-8326-6ece6f73202a	2024-11-02 19:46:16.031912	un-2
8f4b5d20-41c7-4c88-b3d0-1dca595a5c2e	2024-11-02 19:46:17.638376	un-3
e28ddbc3-6036-49c8-ba11-66fb97dc8ca6	2024-11-02 19:46:18.765583	un-4
a354ecf2-d54a-4986-a256-4aca1e583e92	2024-11-02 19:46:20.427617	un-5
\.


--
-- Data for Name: users_chats; Type: TABLE DATA; Schema: public; Owner: dev
--

COPY public.users_chats ("usersId", "chatsId") FROM stdin;
2f889abb-b721-41a0-a13b-674d79f6fc64	4ca4d800-edb9-487c-b2a7-dd18343043ef
b2536577-6df2-42af-8326-6ece6f73202a	4ca4d800-edb9-487c-b2a7-dd18343043ef
8f4b5d20-41c7-4c88-b3d0-1dca595a5c2e	4ca4d800-edb9-487c-b2a7-dd18343043ef
e28ddbc3-6036-49c8-ba11-66fb97dc8ca6	4ca4d800-edb9-487c-b2a7-dd18343043ef
\.


--
-- Name: chats PK_0117647b3c4a4e5ff198aeb6206; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT "PK_0117647b3c4a4e5ff198aeb6206" PRIMARY KEY (id);


--
-- Name: messages PK_18325f38ae6de43878487eff986; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "PK_18325f38ae6de43878487eff986" PRIMARY KEY (id);


--
-- Name: users_chats PK_649ecf9d0f35aa1985f9b247218; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.users_chats
    ADD CONSTRAINT "PK_649ecf9d0f35aa1985f9b247218" PRIMARY KEY ("usersId", "chatsId");


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: chats UQ_f63b5cc5bf67e5251f28301d7e0; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT "UQ_f63b5cc5bf67e5251f28301d7e0" UNIQUE (name);


--
-- Name: users UQ_fe0bb3f6520ee0469504521e710; Type: CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_fe0bb3f6520ee0469504521e710" UNIQUE (username);


--
-- Name: IDX_1ddad94a473a2a60bee5dc6d9d; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "IDX_1ddad94a473a2a60bee5dc6d9d" ON public.users_chats USING btree ("chatsId");


--
-- Name: IDX_a91c85f9e29b30da5629b55521; Type: INDEX; Schema: public; Owner: dev
--

CREATE INDEX "IDX_a91c85f9e29b30da5629b55521" ON public.users_chats USING btree ("usersId");


--
-- Name: users_chats FK_1ddad94a473a2a60bee5dc6d9d0; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.users_chats
    ADD CONSTRAINT "FK_1ddad94a473a2a60bee5dc6d9d0" FOREIGN KEY ("chatsId") REFERENCES public.chats(id);


--
-- Name: messages FK_36bc604c820bb9adc4c75cd4115; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "FK_36bc604c820bb9adc4c75cd4115" FOREIGN KEY ("chatId") REFERENCES public.chats(id);


--
-- Name: messages FK_819e6bb0ee78baf73c398dc707f; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "FK_819e6bb0ee78baf73c398dc707f" FOREIGN KEY ("authorId") REFERENCES public.users(id);


--
-- Name: users_chats FK_a91c85f9e29b30da5629b555216; Type: FK CONSTRAINT; Schema: public; Owner: dev
--

ALTER TABLE ONLY public.users_chats
    ADD CONSTRAINT "FK_a91c85f9e29b30da5629b555216" FOREIGN KEY ("usersId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

